#include "matrix.h"
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

// Include SSE intrinsics
#if defined(_MSC_VER)
#include <intrin.h>
#elif defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__))
#include <immintrin.h>
#include <x86intrin.h>
#endif

#define BLOCK_SIZE 500

/* Generates a random double between low and high */
double rand_double(double low, double high) {
    double range = (high - low);
    double div = RAND_MAX / range;
    return low + (rand() / div);
}

/* Generates a random matrix */
void rand_matrix(matrix *result, double low, double high) {
    srand(42);
    int i, j;
    /*#pragma omp parallel for private(j)*/
    for (i = 0; i < result->rows; ++i) {
        for (j = 0; j < result->cols; j++) {
            set(result, i, j, rand_double(low, high));
        }
    }
}

/*
 * Allocates space for a matrix struct pointed to by the double pointer mat with
 * `rows` rows and `cols` columns. You should also allocate memory for the data array
 * and initialize all entries to be zeros. `parent` should be set to NULL to indicate that
 * this matrix is not a slice. You should also set `ref_cnt` to 1.
 * You should return -1 if either `rows` or `cols` or both have invalid values, or if any
 * call to allocate memory in this function fails. Return 0 upon success.
 */
int allocate_matrix(matrix **mat, int rows, int cols) {
    if (rows <= 0 || cols <= 0) {
        PyErr_SetString(PyExc_TypeError, "Matrix dimensions must be positive");
        return -1;
    }
    matrix* matr = (matrix*) malloc(sizeof(matrix));
    if (matr == NULL) {
        return -1;
    } else {
        *mat = matr;
    }
    matr->rows = rows;
    matr->cols = cols;
    double* dat = (double *) calloc(rows * cols, sizeof(double));
    if (dat == NULL) {
        free(matr);
        return -1;
    } else {
        matr->data = dat;
        memset(dat, 0, rows * cols * sizeof(double));
        /*int x, y, i, j, i_upper, j_upper, j4, index;
        for (x = 0; x < rows; x += BLOCK_SIZE) {
            i_upper = (x + BLOCK_SIZE < rows) ? (x + BLOCK_SIZE) : rows;
            for (y = 0; y < cols; y += BLOCK_SIZE) {
                j_upper = (y + BLOCK_SIZE < cols) ? (y + BLOCK_SIZE) : cols;
                j4 = j_upper / 4 * 4;
                for (i = x; i < i_upper; ++i) {
                    for (j = y; j < j4; j += 4) {
                        index = i * cols + j;
                        dat[index] = 0;
                        dat[index + 1] = 0;
                        dat[index + 2] = 0;
                        dat[index + 3] = 0;
                    }
                    for (j = j4; j < j_upper; j++) {
                        index = i * cols + j;
                        dat[index] = 0;
                    }
                }
            }
        }*/
    }
    matr->ref_cnt = 1;
    matr->parent = NULL;
    return 0;
}

/*
 * Allocates space for a matrix struct pointed to by `mat` with `rows` rows and `cols` columns.
 * Its data should point to the `offset`th entry of `from`'s data (you do not need to allocate memory)
 * for the data field. `parent` should be set to `from` to indicate this matrix is a slice of `from`.
 * You should return -1 if either `rows` or `cols` or both are non-positive or if any
 * call to allocate memory in this function fails. Return 0 upon success.
 */
int allocate_matrix_ref(matrix **mat, matrix *from, int offset, int rows, int cols) {
    if (rows <= 0 || cols <= 0 || from == NULL || from->data == NULL) {
        return -1;
    }
    matrix* matr = (matrix*) malloc(sizeof(matrix));
    if (matr == NULL) {
        return -1;
    } else {
        *mat = matr;
    }
    double* data = ((double*) from->data + offset);
    matr->data = data;
    matr->rows = rows;
    matr->cols = cols;
    matr->parent = from;
    from->ref_cnt += 1;
    matr->ref_cnt = from->ref_cnt;
    return 0;
}

/*
 * This function frees the matrix struct pointed to by `mat`. However, you need to make sure that
 * you only free the data if `mat` is not a slice and has no existing slices, or if `mat` is the
 * last existing slice of its parent matrix and its parent matrix has no other references.
 * You cannot assume that mat is not NULL.
 */
void deallocate_matrix(matrix *mat) {
    if (mat != NULL) {
        if (mat->parent == NULL && mat->ref_cnt <= 1 && mat->data != 0) {
            free(mat->data);
        } else if (mat->parent != NULL) {
            if (mat->parent->ref_cnt <= 0 && mat->parent->data != 0) {
                free(mat->parent->data);
            }
            mat->parent->ref_cnt -= 1;
        }
        free(mat);
    }
}

/*
 * Returns the double value of the matrix at the given row and column.
 * You may assume `row` and `col` are valid.
 */
double get(matrix *mat, int row, int col) {
    return mat->data[row * (mat->cols) + col];
}

/*
 * Sets the value at the given row and column to val. You may assume `row` and
 * `col` are valid
 */
void set(matrix *mat, int row, int col, double val) {
    if (mat != NULL) {
        int cols = mat->cols;
        double* dat = mat->data;
        if (dat == NULL) {
            dat = (double *) calloc(mat->rows * mat->cols, sizeof(double));
            if (dat != NULL) {
                mat->data = dat;
                int rows = mat->rows;
                memset(dat, 0, cols * rows * sizeof(double));
                /*int x, y, i, j, i_upper, j_upper, j4, index;
                for (x = 0; x < mat->rows; x += BLOCK_SIZE) {
                    i_upper = (x + BLOCK_SIZE < rows) ? (x + BLOCK_SIZE) : rows;
                    for (y = 0; y < cols; y += BLOCK_SIZE) {
                        j_upper = (y + BLOCK_SIZE < cols) ? (y + BLOCK_SIZE) : cols;
                        j4 = j_upper / 4 * 4;
                        for (i = x; i < i_upper; ++i) {
                            for (j = y; j < j4; j += 4) {
                                index = i * col + j;
                                dat[index] = 0;
                                dat[index + 1] = 0;
                                dat[index + 2] = 0;
                                dat[index + 3] = 0;
                            }
                            for (j = j4; j < j_upper; j++) {
                                index = i * col + j;
                                dat[index] = 0;
                            }
                        }
                    }
                }*/
            }
        }
        dat[row * cols + col] = val;
    }
}

/*
 * Sets all entries in mat to val
 */
void fill_matrix(matrix *mat, double val) {
    if (mat != NULL) {
        int rows = mat->rows;
        int cols = mat->cols;
        double* dat = mat->data;
        if (dat == NULL) {
            dat = (double *) calloc(rows * cols, sizeof(double));
            mat->data = dat;
        }

        /* SISD */
        /*int x, y, i, j, i_upper, j_upper, j4, index;
        for (x = 0; x < rows; x += BLOCK_SIZE) {
            i_upper = (x + BLOCK_SIZE < rows) ? (x + BLOCK_SIZE) : rows;
            for (y = 0; y < cols; y += BLOCK_SIZE) {
                j_upper = (y + BLOCK_SIZE < cols) ? (y + BLOCK_SIZE) : cols;
                j4 = j_upper / 4 * 4;
                for (i = x; i < i_upper; ++i) {
                    for (j = y; j < j4; j += 4) {
                        index = i * cols + j;
                        dat[index] = val;
                        dat[index + 1] = val;
                        dat[index + 2] = val;
                        dat[index + 3] = val;
                    }
                    for (j = j4; j < j_upper; j++) {
                        index = i * cols + j;
                        dat[index] = val;
                    }
                }
            }
        }*/

        /* MIMD */
        __m256d outcome = _mm256_set1_pd(val);
        int x, y, i, j, i_upper, j_upper, j16, index;
        #pragma omp parallel for private(y, i, j, i_upper, j_upper, j16, index)
        for (x = 0; x < rows; x += BLOCK_SIZE) {
            i_upper = (x + BLOCK_SIZE < rows) ? (x + BLOCK_SIZE) : rows;
            for (y = 0; y < cols; y += BLOCK_SIZE) {
                j_upper = (y + BLOCK_SIZE < cols) ? (y + BLOCK_SIZE) : cols;
                j16 = j_upper / 16 * 16;
                for (i = x; i < i_upper; ++i) {
                    for (j = y; j < j16; j += 16) {
                        index = i * cols + j;
                        _mm256_storeu_pd((dat + index), outcome);
                        _mm256_storeu_pd((dat + index + 4), outcome);
                        _mm256_storeu_pd((dat + index + 8), outcome);
                        _mm256_storeu_pd((dat + index + 12), outcome);
                    }
                    for (j = j16; j < j_upper; j++) {
                        index = i * cols + j;
                        dat[index] = val;
                    }
                }
            }
        }
    }
}

/*
 * Store the result of adding mat1 and mat2 to `result`.
 * Return 0 upon success and a nonzero value upon failure.
 */
int add_matrix(matrix *result, matrix *mat1, matrix *mat2) {
    if (mat1 == NULL || mat2 == NULL || result == NULL) {
        return -1;
    }
    /* if (result == NULL) {
        if (allocate_matrix(&result, mat1->rows, mat1->cols) != 0) {
            return -1;
        }
    } */
    int row1 = mat1->rows;
    if (row1 != result->rows || row1 != mat2->rows) {
        return -1;
    }
    int col1 = mat1->cols;
    if (col1 != result->cols || col1 != mat2->cols) {
        return -1;
    }
    double* dat1 = mat1->data;
    double* dat2 = mat2->data;
    if (mat1->data == NULL || mat2->data == NULL) {
        return -1;
    }
    double* dat0 = result->data;
    if (dat0 == NULL) {
        dat0 = (double *) calloc(row1 * col1, sizeof(double));
        if (dat0 == NULL) {
            return -1;
        } else {
            result->data = dat0;
        }
    }
    int x, y, i, j, i_upper, j_upper, j4, index;
    #pragma omp parallel for private(y, i, j, i_upper, j_upper, j4, index)
    for (x = 0; x < row1; x += BLOCK_SIZE) {
        i_upper = (x + BLOCK_SIZE < row1) ? (x + BLOCK_SIZE) : row1;
        for (y = 0; y < col1; y += BLOCK_SIZE) {
            j_upper = (y + BLOCK_SIZE < col1) ? (y + BLOCK_SIZE) : col1;
            j4 = j_upper / 4 * 4;
            for (i = x; i < i_upper; ++i) {
                for (j = y; j < j4; j += 4) {
                    index = i * col1 + j;
                    dat0[index] = dat1[index] + dat2[index];
                    dat0[index + 1] = dat1[index + 1] + dat2[index + 1];
                    dat0[index + 2] = dat1[index + 2] + dat2[index + 2];
                    dat0[index + 3] = dat1[index + 3] + dat2[index + 3];
                }
                for (j = j4; j < j_upper; j++) {
                    index = i * col1 + j;
                    dat0[index] = dat1[index] + dat2[index];
                }
            }
        }
    }
    return 0;
}

/*
 * Store the result of subtracting mat2 from mat1 to `result`.
 * Return 0 upon success and a nonzero value upon failure.
 */
int sub_matrix(matrix *result, matrix *mat1, matrix *mat2) {
    if (mat1 == NULL || mat2 == NULL || result == NULL) {
        return -1;
    }
    int row1 = mat1->rows;
    if (row1 != result->rows || row1 != mat2->rows) {
        return -1;
    }
    int col1 = mat1->cols;
    if (col1 != result->cols || col1 != mat2->cols) {
        return -1;
    }
    double* dat1 = mat1->data;
    double* dat2 = mat2->data;
    if (mat1->data == NULL || mat2->data == NULL) {
        return -1;
    }
    double* dat0 = result->data;
    if (dat0 == NULL) {
        dat0 = (double *) calloc(row1 * col1, sizeof(double));
        if (dat0 == NULL) {
            return -1;
        } else {
            result->data = dat0;
        }
    }
    int x, y, i, j, i_upper, j_upper, j4, index;
    #pragma omp parallel for private(y, i, j, i_upper, j_upper, j4, index)
    for (x = 0; x < row1; x += BLOCK_SIZE) {
        i_upper = (x + BLOCK_SIZE < row1) ? (x + BLOCK_SIZE) : row1;
        for (y = 0; y < col1; y += BLOCK_SIZE) {
            j_upper = (y + BLOCK_SIZE < col1) ? (y + BLOCK_SIZE) : col1;
            j4 = j_upper / 4 * 4;
            for (i = x; i < i_upper; ++i) {
                for (j = y; j < j4; j += 4) {
                    index = i * col1 + j;
                    dat0[index] = dat1[index] - dat2[index];
                    dat0[index + 1] = dat1[index + 1] - dat2[index + 1];
                    dat0[index + 2] = dat1[index + 2] - dat2[index + 2];
                    dat0[index + 3] = dat1[index + 3] - dat2[index + 3];
                }
                for (j = j4; j < j_upper; j++) {
                    index = i * col1 + j;
                    dat0[index] = dat1[index] - dat2[index];
                }
            }
        }
    }
    return 0;
}

/*
 * Store the result of multiplying mat1 and mat2 to `result`.
 * Return 0 upon success and a nonzero value upon failure.
 * Remember that matrix multiplication is not the same as multiplying individual elements.
 */
 int mul_matrix(matrix *result, matrix *mat1, matrix *mat2) {
     if (mat1 == NULL || mat2 == NULL || result == NULL) {
         return -1;
     }
     int m = result->rows;
     int p = mat1->cols;
     int n = result->cols;
     if (m != mat1->rows || p != mat2->rows || n != mat2->cols) {
         return -1;
     }
     double* dat1 = mat1->data;
     double* dat2 = mat2->data;
     if (dat1 == NULL || dat2 == NULL) {
         return -1;
     }
     double* dat0 = result->data;
     if (result->data == NULL) {
         dat0 = (double *) calloc(m * n, sizeof(double));
         if (dat0 == NULL) {
             return -1;
         } else {
             result->data = dat0;
         }
     }
     double* results = (double *) calloc(m * n, sizeof(double));
     if (results == NULL) {
         return -1;
     }
     int x, y, i, j, k, i_upper, j_upper, index, indexk;
     int p4 = p / 4 * 4;
     #pragma omp parallel for private(y, i, j, k, i_upper, j_upper, index, indexk)
     for (x = 0; x < m; x += BLOCK_SIZE) {
         i_upper = (x + BLOCK_SIZE < m) ? (x + BLOCK_SIZE) : m;
         for (y = 0; y < n; y += BLOCK_SIZE) {
             j_upper = (y + BLOCK_SIZE < n) ? (y + BLOCK_SIZE) : n;
             for (i = x; i < i_upper; ++i) {
                 for (j = y; j < j_upper; j++) {
                     index = i * n + j;
                     for (k = 0; k < p4; k += 4) {
                         indexk = i * p + k;
                         results[index] += dat1[indexk] * dat2[k * n + j] + dat1[indexk + 1] * dat2[(k + 1) * n + j] + dat1[indexk + 2] * dat2[(k + 2) * n + j] + dat1[indexk + 3] * dat2[(k + 3) * n + j];
                     }
                     for (k = p4; k < p; k++) {
                     	results[index] += dat1[i * p + k] * dat2[k * n + j];
                     }
                 }
             }
         }
     }
     memcpy(dat0, results, m * n * sizeof(double));
     free(results);
     return 0;
 }

/*
 * Store the result of raising mat to the (pow)th power to `result`.
 * Return 0 upon success and a nonzero value upon failure.
 * Remember that pow is defined with matrix multiplication, not element-wise multiplication.
 */
int pow_matrix(matrix *result, matrix *mat, int pow) {
    if (pow <= 0 || mat == NULL || result == NULL) {
        return -1;
    }
    int n = mat->rows;
    if (n != mat->cols || n != result->rows || n != result->cols) {
        return -1;
    }
    double* dat1 = mat->data;
    if (dat1 == NULL) {
        return -1;
    }
    double* dat0 = result->data;
    if (result->data == NULL) {
        dat0 = (double *) calloc(n * n, sizeof(double));
        if (dat0 == NULL) {
            return -1;
        } else {
            result->data = dat0;
        }
    }
    double* intermediate = (double *) calloc(n * n, sizeof(double));
    if (intermediate == NULL) {
        return -1;
    }
    /*double* results = (double *) malloc(n * n * sizeof(double));
    if (results == NULL) {
        return -1;
    }*/
    memcpy(intermediate, dat1, n * n * sizeof(double));
    int x, y, i, j, k, i_upper, j_upper, index, indexk;
    int n4 = n / 4 * 4;
    int p;
    for (p = 1; 2 * p < pow ; p *= 2) {
        memset(dat0, 0, n * n * sizeof(double));
        #pragma omp parallel for private(y, i, j, i_upper, j_upper, indexk, index)
        for (x = 0; x < n; x += BLOCK_SIZE) {
            i_upper = (x + BLOCK_SIZE < n) ? (x + BLOCK_SIZE) : n;
            for (y = 0; y < n; y += BLOCK_SIZE) {
                j_upper = (y + BLOCK_SIZE < n) ? (y + BLOCK_SIZE) : n;
                for (i = x; i < i_upper; ++i) {
                    for (j = y; j < j_upper; j++) {
                        index = i * n + j;
                        for (k = 0; k < n4; k += 4) {
                            indexk = i * n + k;
                            dat0[index] += intermediate[indexk] * intermediate[k * n + j] + intermediate[indexk + 1] * intermediate[(k + 1) * n + j] + intermediate[indexk + 2] * intermediate[(k + 2) * n + j] + intermediate[indexk + 3] * intermediate[(k + 3) * n + j];
                        }
                        for (k = n4; k < n; k++) {
                        	dat0[index] += intermediate[i * n + k] * intermediate[k * n + j];
                        }
                    }
                }
            }
        }
        memcpy(intermediate, dat0, n * n * sizeof(double));
    }
    for (; p < pow ; p += 1) {
        memset(dat0, 0, n * n * sizeof(double));
        #pragma omp parallel for private(y, i, j, i_upper, j_upper, indexk, index)
        for (x = 0; x < n; x += BLOCK_SIZE) {
            i_upper = (x + BLOCK_SIZE < n) ? (x + BLOCK_SIZE) : n;
            for (y = 0; y < n; y += BLOCK_SIZE) {
                j_upper = (y + BLOCK_SIZE < n) ? (y + BLOCK_SIZE) : n;
                for (i = x; i < i_upper; ++i) {
                    for (j = y; j < j_upper; j++) {
                        index = i * n + j;
                        for (k = 0; k < n4; k += 4) {
                            indexk = i * n + k;
                            dat0[index] += dat1[indexk] * intermediate[k * n + j] + dat1[indexk + 1] * intermediate[(k + 1) * n + j] + dat1[indexk + 2] * intermediate[(k + 2) * n + j] + dat1[indexk + 3] * intermediate[(k + 3) * n + j];
                        }
                        for (k = n4; k < n; k++) {
                        	dat0[index] += dat1[i * n + k] * intermediate[k * n + j];
                        }
                    }
                }
            }
        }
        memcpy(intermediate, dat0, n * n * sizeof(double));
    }
    memcpy(dat0, intermediate, n * n * sizeof(double));
    free(intermediate);
    return 0;
}

/*
 * Store the result of element-wise negating mat's entries to `result`.
 * Return 0 upon success and a nonzero value upon failure.
 */
int neg_matrix(matrix *result, matrix *mat) {
    if (mat == NULL || result == NULL) {
        return -1;
    }
    int rows = mat->rows;
    if (rows != result->rows) {
        return -1;
    }
    int cols = mat->cols;
    if (cols != result->cols) {
        return -1;
    }
    double* dat1 = mat->data;
    if (dat1 == NULL) {
        return -1;
    }
    double* dat0 = result->data;
    if (result->data == NULL) {
        dat0 = (double *) calloc(rows * cols, sizeof(double));
        if (dat0 == NULL) {
            return -1;
        } else {
            result->data = dat0;
        }
    }
    int x, y, i, j, i_upper, j_upper, j4, index;
    #pragma omp parallel for private(y, i, j, i_upper, j_upper, j4, index)
    for (x = 0; x < rows; x += BLOCK_SIZE) {
        i_upper = (x + BLOCK_SIZE < rows) ? (x + BLOCK_SIZE) : rows;
        for (y = 0; y < cols; y += BLOCK_SIZE) {
            j_upper = (y + BLOCK_SIZE < cols) ? (y + BLOCK_SIZE) : cols;
            j4 = j_upper / 4 * 4;
            for (i = x; i < i_upper; ++i) {
                for (j = y; j < j4; j += 4) {
                    index = i * cols + j;
                    dat0[index] = - dat1[index];
                    dat0[index + 1] = - dat1[index + 1];
                    dat0[index + 2] = - dat1[index + 2];
                    dat0[index + 3] = - dat1[index + 3];
                }
                for (j = j4; j < j_upper; j++) {
                    index = i * cols + j;
                    dat0[index] = - dat1[index];
                }
            }
        }
    }
    return 0;
}

/*
 * Store the result of taking the absolute value element-wise to `result`.
 * Return 0 upon success and a nonzero value upon failure.
 */
int abs_matrix(matrix *result, matrix *mat) {
    if (mat == NULL || result == NULL) {
        return -1;
    }
    int rows = mat->rows;
    if (rows != result->rows) {
        return -1;
    }
    int cols = mat->cols;
    if (cols != result->cols) {
        return -1;
    }
    double* dat1 = mat->data;
    if (dat1 == NULL) {
        return -1;
    }
    double* dat0 = result->data;
    if (result->data == NULL) {
        dat0 = (double *) calloc(rows * cols, sizeof(double));
        if (dat0 == NULL) {
            return -1;
        } else {
            result->data = dat0;
        }
    }
    int x, y, i, j, i_upper, j_upper, j4, index;
    double got;
    #pragma omp parallel for private(y, i, j, i_upper, j_upper, j4, index, got)
    for (x = 0; x < rows; x += BLOCK_SIZE) {
        i_upper = (x + BLOCK_SIZE < rows) ? (x + BLOCK_SIZE) : rows;
        for (y = 0; y < cols; y += BLOCK_SIZE) {
            j_upper = (y + BLOCK_SIZE < cols) ? (y + BLOCK_SIZE) : cols;
            j4 = j_upper / 4 * 4;
            for (i = x; i < i_upper; ++i) {
                /* Loop unrolling */
                for (j = y; j < j4; j += 4) {
                    index = i * cols + j;
                    got = dat1[index];
                    dat0[index] = (got >= 0)? got : -got;
                    got = dat1[index + 1];
                    dat0[index + 1] = (got >= 0)? got : -got;
                    got = dat1[index + 2];
                    dat0[index + 2] = (got >= 0)? got : -got;
                    got = dat1[index + 3];
                    dat0[index + 3] = (got >= 0)? got : -got;
                }
                /*/*#pragma omp parallel for private(index, got)*/
                for (j = j4; j < j_upper; j++) {
                    index = i * cols + j;
                    got = dat1[index];
                    if (got >= 0) {
                        dat0[index] = got;
                    } else {
                        dat0[index] = -got;
                    }
                    /*dat0[index] = (got >= 0) ? got : -got;*/
                }
            }
        }
    }
    return 0;
}
