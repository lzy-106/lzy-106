# numc

_____   __                 _________
___  | / /___  _______  _____  ____/
__   |/ /_  / / /_  _ \/ _ \  /
_  /|  / / /_/ /_  / / / / / /___
/_/ |_/  \____/ /_/ /_/ /_/\____/

\'The (200th) fastest hunk of junk in c-yberspace\'

Here's what I did in this project:
-
I completed the implementation of 'NumC', a Python extension for matrix manipulations written in C, connected through Python's 'distutils' module. The connections are setup in 'setup.py' and 'numc.c'.
This is a school project, and most of 'numc.c' and 'numc.h' are given by instructors. I wrote the vast majority of other code.

The matrixes are implemented in row-major order.
Most errors are handl ded in the Python-C interface, 'numc.c'. However, 'allocate_matrix' in 'matrix.c' checks whether the input dimensions are positive & throws a 'TypeError' if not, as it is called too many times in 'numc.c' and this check would be redundant if written multiple times, though my implementation breaches modularity and the abstraction barrier.
Many number methods are accelerated with cache blocking to maximise spatial locality and loop-unrolled 4 times to reduce looping overhead. The blocks are 500 \* 500. The C conditional operator '?' is extensively used in minimising stop-condition arguments to prevent accesses to forbidden addresses.

## Installation
'NumC' should be imported as
'''
from numc import Matrix
'''

## Usage

### Initialisation
'NumC' usage is focused around its 'Matrix' objects containing double-precision floating point numbers. There are multiple ways to initialise one.
'Matrix(rows: int, cols: int)' creates a matrix w'i'th 'rows' rows and 'cols' columns and initialises all entries to be 0.
'Matrix(rows: int, cols: int, val: float)' creates a matrix w'i'th 'rows' rows and 'cols' columns and initialises all entries to be 'val'.
'Matrix(rows: int, cols: int, lst: List[int])' creates a matrix w'i'th 'rows' rows and 'cols' columns and initialises all entries to be 'val'. 'lst' must have length 'rows' * 'cols', else a TypeError would be thrown. The entries of the matrix will be initialised to values of 'lst' in row-major order.
'Matrix(lst: List[List[int]])' creates a matrix w'i'th the same shape as the 2D lst. Each sub-list in 'lst' will be a row for the matrix.

The functions are realised by the C function 'allocate_matrix' in 'matrix.c', which checks the dimensions and throws a 'TypeError' w'i'th the appropriate error message if they are not positive integers. It then allocates memory space, and failure in doing so results in a 'RuntimeError'. The zero-filling is implemented through 'memset', a serial function that I hope will be the most robust because it is the most native to C. It is also faster to write.
'deallocate_matrix' automatically garbage-collects matrices no longer pointed to. It also frees pointers to their data arrays in certain conditions based on struct attribute 'ref_cnt', which have been hard to get right. My main errors are freeing pointers halfway in a 'malloc'ed array and not decrementing the 'ref_cnt' of parents when their children are deallocated.

### Indexing
A row or an entry of a 'Matrix' can be indexed as if it is a 2D list, e.g. 'mat1[i]' for the 'i'th row of 'mat1', or 'mat[i][j]' for the 'j'th entry of the 'i'th row.
If mat only has one column, then 'mat[i]' will return a double. Else, it will return a row slice of 'mat', and any change to that slice will change 'mat', too. Any change in 'mat[i][j]' will also change the entry in 'mat' if the assigned value is a float or an int. Setting an entire row of a matrix that has more than one column requires a 1D list that has the same length as the number of columns of that matrix, w'i'th every element of type float or int.
An index out of bounds would result in an 'IndexError'. Only non-negative indices are supported, and other indices will result in a 'TypeError'. Partial slices are not supported. I threw the wrong errors for several versions of my code.

The creation of the mutable slices are implemented in 'allocate_matrix_ref'.

### Instance Attribute
'Matrix'es and their row slices have an attribute 'shape', a tuple of ('rows', 'cols').


### Instance Methods
'Matrix'es have two instance methods to get & set one entry at a time.

'set(self: Matrix, i: int, j: int, val: float): It sets the entry at the 'i'th row and 'j'th column of 'self' to 'val'. Returns None, which seems to be a constant in Python like NULL in C. Throws an 'IndexError' if either 'i' or 'j' is out of range, including the case in which any is negative. Throws a 'TypeError' if the number of arguments parsed from args is not 3 or if the arguments are of the wrong types.
I have found array-style accesses like 'arr[i]' to be way cleaner and easier to debug than pointer-style accesses like '\*(arr + i)'.
'get(self: Matrix, i: int, j: int)'': Returns the entry at the 'i'th row and 'j'th column. Throw a type error if the number of arguments parsed from args is not 2 or if either argument is of the wrong type. Throws an index error if either is out of range, including the case in which any is negative. Returns a Python float.

### Number Methods
Some number operators like '+', '-', '*' and '**' are overloaded as matrix operators. All results are returned in a newly allocated matrix. A failure in allocation results in a 'RuntimeError'.

'a + b': Matrix sum of 'a' and 'b'. Returns a Matrix object. Throws a 'TypeError' if 'a' and 'b' do not have the same dimensions.
Implemented in 'add_matrix'. Accelerated by cache blocking, loop unrolling, and OpenMP MIMD.
'a - b': Matrix subtraction of 'a' and b. Returns a Matrix object. Throws a 'TypeError' if 'a' and 'b' do not have the same dimensions.
Implemented in 'sub_matrix'. Accelerated by cache blocking, loop unrolling, and OpenMP MIMD.
a * b: Matrix multiplication of 'a' and b. Returns a Matrix object. Throws a 'TypeError' if the width of 'a' is unequal to the height of 'b'
-a: Element-wise negation of 'a'. Returns a Matrix.
Implemented in 'mul_matrix'. It allocates a new array, stores the result in it, copies it back with 'memcpy', and then frees it. That is to prevent changing 'a' during the operation.
Accelerated by cache blocking, loop unrolling, and OpenMP MIMD. The loop-unrolling calculates four addends before adding them first altogether and then to the target entry. That scheme aims to reduce data race for writing to the sum entry.
The OpenMP pragma is applied to the outermost loop, and all changing variables inside are set to be thread-private. Still, even without OpenMP, the precision of the results seem to fluctuate.
abs(a): Element-wise absolute value of 'a'. Returns a Matrix.
Implemented in 'abs_matrix'. Accelerated by cache blocking, loop unrolling, and OpenMP MIMD. I wasted a day on the wrong declaration of the retrieved 'double' entries as 'int'.
a ** pow: Raise 'a' to the 'pow'th power.Returns a Matrix. 'pow' must be a positive integer and 'a' must be square, else a TypeError would be thrown.
Implemented in 'pow_matrix'. It first use repeated squares until 'pow // 2', and then repeats multiplying the intermediate result with 'a' until the final power is achieved. It store the result of any previous multiplication in a new array, stores the result during a multiplication in the target matrix, and copies it to the new array for each iteration. In the end, it frees that new array.
Accelerated by cache blocking, loop unrolling, and OpenMP MIMD. The loop-unrolling calculates four addends before adding them first altogether and then to the target entry. That scheme aims to reduce data race for writing to the sum entry.
The OpenMP pragma is applied to the outermost loop, and all changing variables inside are set to be thread-private. Weirdly enough, this is much more robust than the similar yet simpler 'mul_matrix'.

## Conclusion
The end result speeds multiply up somewhat, power much more because it is more complex, and comprehensive sets of operations only a bit because only parts of them can be accelerated, according to Amdahl's law.
