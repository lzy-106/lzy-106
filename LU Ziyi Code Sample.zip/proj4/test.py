import numc as nc
# This creates a 3 * 3 matrix with entries all zeros
mat1 = nc.Matrix(3, 3)
# mat1 = nc.Matrix(3, -3)

# This creates a 2 * 3 matrix with entries all ones
mat2 = nc.Matrix(2, 3, 1)

# This creates a 2 * 3 matrix with first row 1, 2, 3, second row 4, 5, 6
mat3 = nc.Matrix([[1, -2, 3], [-4, 5, -6]])

# This creates a 1 * 2 matrix with entries 4, 5
mat4 = nc.Matrix(1, 2, [4, -5])

# INDEXING
# mat1
# this gives the 0th row of mat1, should print out [[0.0], [0.0], [0.0]]
print(mat1[0])
print(mat1[0][1])  # this should print out 0
mat1[0][1] = 5
# this should print out [[0.0, 5.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
print(mat1)
mat1[0] = [4.5, 5, 6]
# this should print out [[4.0, 5.0, 6.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
print(mat1)

# mat2
print(mat2)  # [[1.0, 1.0, 1.0], [1.0, 1.0, 1.0], [1.0, 1.0, 1.0]]
mat2[1][1] = 2
print(mat2[1])  # [[1.0], [2.0], [1.0]]

# You can change a value in a slice, and that will change the original matrix
print(mat2)  # [[1.0, 1.0, 1.0], [1.0, 2.0, 1.0], [1.0, 1.0, 1.0]]
mat2_slice = mat2[0]  # [[1.0], [1.0], [1.0]]
mat2_slice[0] = 5
print(mat2_slice)  # [[5.0], [1.0], [1.0]]
print(mat2)  # [[5.0, 1.0, 1.0], [1.0, 2.0, 1.0], [1.0, 1.0, 1.0]]

# SHAPE
print(mat1.shape)  # this should print out (3, 3)

# print('mat1', mat1.get(0, -1))
# print('mat1', mat1.get(-1, 0))
# print('mat2', mat2[-2])
print('mat3', mat3)
print('mat4', mat4)

# MULTIPLICATION
print()
print('mat1 * mat1', mat1 * mat1)
print('mat2 * mat1', mat2 * mat1)
print('mat3 * mat1', mat3 * mat1)
print('mat4 * mat2', mat4 * mat2)
print('mat4 * mat3', mat4 * mat3)
# print('mat3 * mat4', mat3 * mat4)

# ADDITION
print()
print('mat1 + mat1', mat1 + mat1)
print('mat2 + mat2', mat2 + mat2)
print('mat2 + mat3', mat2 + mat3)
print('mat3 + mat3', mat3 + mat3)
print('mat4 + mat4', mat4 + mat4)
# print('mat1 + mat2', mat1 + mat2)

# ABSOLUTION
print()
print('abs(mat1)', abs(mat1))
print('abs(mat2)', abs(mat2))
print('abs(mat3)', abs(mat3))
print('abs(mat4)', abs(mat4))

# POWER
print()
print('mat1', mat1)
print('mat1 ** 100', mat1 ** 100)
# print('mat1 ** 0', mat1 ** 0)
# print('mat1 ** -1', mat1 ** -2)
print('mat1 ** 2.5', mat1 ** 2.5)
